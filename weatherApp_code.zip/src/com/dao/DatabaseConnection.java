package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
 
public class DatabaseConnection {
 
    final String DB_URL = "jdbc:mysql://localhost:3306/APP"; // Specify the database name here
    final String USER = "root";
    final String PASS = "A@nu01shi";
    private int no;
 
    public int getNo() {
        return no;
    }
 
    public void setNo(int no) {
        this.no = no;
    }
 
    private static Connection conn;
 
    public DatabaseConnection() {
        try {
            conn = DriverManager.getConnection(DB_URL, USER, PASS);
            createTable(); // Call createTable method in the constructor
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    
 
    public void createTable() {
        try (Statement stmt = conn.createStatement()) {
            String createTableSQL1 = "CREATE TABLE IF NOT EXISTS weather ("
                    + "id INTEGER PRIMARY KEY AUTO_INCREMENT,"
            		+ "region_id INTEGER,"
                    + "city VARCHAR(255),"
            		+ "state VARCHAR(255),"
                    + "date VARCHAR(255),"
            		+ "temp INTEGER,"
                    + "humidity VARCHAR(255))";
 
            stmt.executeUpdate(createTableSQL1);
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
 
    public void executeSQL1(int id, int region_id,String city, String state, String date, int temp, String humidity) {
        try (Connection connection = DriverManager.getConnection(DB_URL, USER, PASS);
             PreparedStatement preparedStatement = connection.prepareStatement(
                     "INSERT INTO weather (id,region_id,city,state,date,temp,humidity) VALUES (?, ?, ?, ?, ?, ?, ?)",
                     Statement.RETURN_GENERATED_KEYS)) {
 
            preparedStatement.setInt(1,id);
            preparedStatement.setInt(2,region_id);
            preparedStatement.setString(3,city);
            preparedStatement.setString(4,state);
            preparedStatement.setString(5,date);
            preparedStatement.setInt(6,temp);
            preparedStatement.setString(7,humidity);
 
            int affectedRows = preparedStatement.executeUpdate();
 
            if (affectedRows > 0) {
                try (ResultSet generatedKeys = preparedStatement.getGeneratedKeys()) {
                    if (generatedKeys.next()) {
                        this.setNo(generatedKeys.getInt(1));
                        System.out.println("Data created successfully with Index No: " + this.getNo());
                    }
                }
            } else {
                System.out.println("Failed.");
            }
        }
 
            catch (SQLException ex) {
                ex.printStackTrace();
            }
        }
    }
 
