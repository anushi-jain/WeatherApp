package com.dao;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class OtherFunc {

    private static final String DB_URL = "jdbc:mysql://localhost:3306/app";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "A@nu01shi";
    
    private static final String MAX_TEMP_CITY_IN_MAY_SQL = "SELECT city FROM weather WHERE MONTH(STR_TO_DATE(date, '%d-%m-%Y')) = 5 ORDER BY temp DESC LIMIT 1";
    private static final String AVG_TEMP_BY_STATE_SQL =
            "SELECT state, AVG(temp) as avg_temp FROM weather GROUP BY state";

    public String findStateWithMaxTempInMay() {
    	try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                PreparedStatement preparedStatement = conn.prepareStatement(MAX_TEMP_CITY_IN_MAY_SQL);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            if (resultSet.next()) {
                return resultSet.getString("city");
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return null;
    }

    public double getAverageTempByState(String state) {
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = conn.prepareStatement(AVG_TEMP_BY_STATE_SQL)) {

            ResultSet resultSet = preparedStatement.executeQuery();

            while (resultSet.next()) {
                String currentState = resultSet.getString("state");
                if (currentState.equalsIgnoreCase(state)) {
                    return resultSet.getDouble("avg_temp");
                }
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return 0.0; 
    }
}
