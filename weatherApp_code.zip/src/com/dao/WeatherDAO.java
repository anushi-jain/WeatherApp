package com.dao;
//import java.sql.Connection;
//import java.sql.PreparedStatement;
//import java.sql.ResultSet;
//import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.sql.*;

import com.model.WeatherData;
import com.exception.DuplicateWeatherDataException;
import com.exception.InvalidTemperatureException;
import com.exception.WeatherDataNotFoundException;


public class WeatherDAO {

	private static final String INSERT_SQL = "INSERT INTO weather (id, region_id, city, state, date, temp, humidity) VALUES (?, ?, ?, ?, ?, ?, ?)";
    private static final String SELECT_ALL_SQL = "SELECT * FROM weather";
    private static final String DELETE_SELECTED_SQL = "DELETE FROM weather where id = ? ";
    private static final String UPDATE_WEATHER_SQL = "UPDATE weather SET humidity = 'high' WHERE MONTH(STR_TO_DATE(date, '%d-%m-%Y')) = 7 and humidity = 'low'";
    
    private static final String CHECK_DUPLICATE_WEATHER_SQL = "SELECT COUNT(*) FROM weather WHERE region_id = ? AND date = ?";

    private static final String DB_URL = "jdbc:mysql://localhost:3306/app";
    private static final String DB_USER = "root";
    private static final String DB_PASSWORD = "A@nu01shi";
    
    private static final int MIN_VALID_TEMPERATURE = -4; 
    private static final int MAX_VALID_TEMPERATURE = 50;

    public void insertWeatherData(WeatherData w) throws DuplicateWeatherDataException, InvalidTemperatureException{
    	
    	if(isDuplicateWeatherData(w.getRegionId(), w.getDate())) {
            throw new DuplicateWeatherDataException("Duplicate weather data: Same region_id and date can't have different temp.");
        }
    	
    	if (!isValidTemperature(w.getTemperature())) {
            throw new InvalidTemperatureException("Invalid temperature: " + w.getTemperature());
        }
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = conn.prepareStatement(INSERT_SQL)) {

            preparedStatement.setInt(1, w.getNo());
            preparedStatement.setInt(2, w.getRegionId());
            preparedStatement.setString(3, w.getCity());
            preparedStatement.setString(4, w.getState());

            // Assuming the date is stored as a string in "dd-MM-yyyy" format
            preparedStatement.setString(5, w.getDate());

            preparedStatement.setInt(6, w.getTemperature());
            preparedStatement.setString(7, w.getHumidity());
            
            System.out.println("SQL Query: " + preparedStatement.toString());

            preparedStatement.executeUpdate();

        } catch (SQLException e) {
        	e.printStackTrace();
        }
    }

//to handle duplicate entry while inserting
    public boolean isDuplicateWeatherData(int regionId, String date) {
    	
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = conn.prepareStatement(CHECK_DUPLICATE_WEATHER_SQL)) {

        	preparedStatement.setInt(1, regionId);
            preparedStatement.setString(2, date);

            ResultSet resultSet = preparedStatement.executeQuery();
            if (resultSet.next()) {
                int count = resultSet.getInt(1);
                return count > 0;
            }

        } catch (SQLException e) {
            // Log or throw a custom exception here
            e.printStackTrace();
        }

        return false;
    }
    
  //to handle valid temp while inserting
    private boolean isValidTemperature(int temperature) {
        return temperature >= MIN_VALID_TEMPERATURE && temperature <= MAX_VALID_TEMPERATURE;
    }
    
    public void deleteWeatherData(int index) throws WeatherDataNotFoundException {
    	if (!isWeatherDataExists(index)) {
            throw new WeatherDataNotFoundException("Weather data not found for ID: " + index);
        }
        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = conn.prepareStatement(DELETE_SELECTED_SQL)) {

            preparedStatement.setInt(1,index);
            
            int rowsAffected = preparedStatement.executeUpdate();

            if (rowsAffected == 0) {
                throw new WeatherDataNotFoundException("No matching records found for deletion with ID: " + index);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }
    }
//checking weather that id exists in rec or not
    public boolean isWeatherDataExists(int id) {
    	try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                PreparedStatement preparedStatement = conn.prepareStatement("SELECT COUNT(*) FROM weather WHERE id = ?")) {

               preparedStatement.setInt(1, id);

               ResultSet resultSet = preparedStatement.executeQuery();
               if (resultSet.next()) {
                   int count = resultSet.getInt(1);
                   return count > 0;
           } }catch (SQLException e) {
               e.printStackTrace();
           }
           
        return false;
    }
        
//updating humidity for the month of july    
    public void updateWeatherData() {
            try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
                 PreparedStatement preparedStatement = conn.prepareStatement(UPDATE_WEATHER_SQL)) {
            	
            	int rowsAffected = preparedStatement.executeUpdate();

                if (rowsAffected > 0) {
                    System.out.println("Humidity updated successfully for records with July as the month. "+ rowsAffected);
                } else {
                    System.out.println("No matching records found for humidity update in July.");
                }

            } catch (SQLException e) {
                // Log or throw a custom exception here
                e.printStackTrace();
            }

     }
    
    
    //SHOWING OF ALL DATA
    public List<WeatherData> getAllWeatherData() {
        List<WeatherData> wList = new ArrayList<>();

        try (Connection conn = DriverManager.getConnection(DB_URL, DB_USER, DB_PASSWORD);
             PreparedStatement preparedStatement = conn.prepareStatement(SELECT_ALL_SQL);
             ResultSet resultSet = preparedStatement.executeQuery()) {

            while (resultSet.next()) {
                
            	 WeatherData weatherData = new WeatherData();
                 weatherData.setNo(resultSet.getInt("id"));
                 weatherData.setRegionId(resultSet.getInt("region_id"));
                 weatherData.setCity(resultSet.getString("city"));
                 weatherData.setState(resultSet.getString("state"));
                 weatherData.setDate(resultSet.getString("date"));
                 weatherData.setTemperature(resultSet.getInt("temp"));
                 weatherData.setHumidity(resultSet.getString("humidity"));

                wList.add(weatherData);
            }

        } catch (SQLException e) {
            e.printStackTrace();
        }

        return wList;
    }

}