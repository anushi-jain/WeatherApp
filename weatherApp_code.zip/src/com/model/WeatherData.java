package com.model;

public class WeatherData {
    private int no;
    private int regionId;
    private String city;
    private String state;
    private String date;
    private int temperature;
    private String humidity;

    // Constructor
    public void weatherData(int no, int regionId, String city, String state, String date, int temperature, String humidity) {
        this.no = no;
        this.regionId = regionId;
        this.city = city;
        this.state = state;
        this.date = date;
        this.temperature = temperature;
        this.humidity = humidity;
    }

    // Getter and setter methods

    public int getNo() {
        return no;
    }

    public void setNo(int no) {
        this.no = no;
    }

    public int getRegionId() {
        return regionId;
    }

    public void setRegionId(int regionId) {
        this.regionId = regionId;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public int getTemperature() {
        return temperature;
    }

    public void setTemperature(int temperature) {
        this.temperature = temperature;
    }

    public String getHumidity() {
        return humidity;
    }

    public void setHumidity(String humidity) {
        this.humidity = humidity;
    }

    @Override
    public String toString() {
        return "WeatherData{" +
                "id=" + no +
                ", regionId=" + regionId +
                ", city='" + city  + '\''+
                ", state='" + state + '\'' +
                ", date=" + date +
                ", temperature=" + temperature +
                ", humidity='" + humidity + '\'' +
                '}';
    }

}