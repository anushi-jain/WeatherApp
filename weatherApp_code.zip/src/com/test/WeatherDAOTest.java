package com.test;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

import com.dao.WeatherDAO;
import com.exception.DuplicateWeatherDataException;
import com.exception.InvalidTemperatureException;
import com.exception.WeatherDataNotFoundException;
import com.model.WeatherData;
import org.junit.jupiter.api.BeforeAll;

import java.util.List;

 
public class WeatherDAOTest {
 
    private static WeatherDAO weatherDAO;
 
    @BeforeAll
    static void setUp() {
        weatherDAO = new WeatherDAO();
    }
 
    @Test
    void testInsertWeatherData() throws DuplicateWeatherDataException, InvalidTemperatureException {
        WeatherData weatherData = new WeatherData();
        weatherData.setNo(1);
        weatherData.setRegionId(1);
        weatherData.setCity("TestCity");
        weatherData.setState("TestState");
        weatherData.setDate("01-01-2023");
        weatherData.setTemperature(25);
        weatherData.setHumidity("High");
 
        assertDoesNotThrow(() -> weatherDAO.insertWeatherData(weatherData));
    }
 
    @Test
    void testIsDuplicateWeatherData() {
        assertFalse(weatherDAO.isDuplicateWeatherData(1, "01-01-2023"));
    }

 
    @Test
    void testDeleteWeatherData() throws WeatherDataNotFoundException {
        assertDoesNotThrow(() -> weatherDAO.deleteWeatherData(1));
        assertThrows(WeatherDataNotFoundException.class, () -> weatherDAO.deleteWeatherData(-1));
    }
 
    @Test
    void testUpdateWeatherData() {
        assertDoesNotThrow(() -> weatherDAO.updateWeatherData());
    }
 
    @Test
    void testGetAllWeatherData() {
        List<WeatherData> weatherDataList = weatherDAO.getAllWeatherData();
        assertNotNull(weatherDataList);
        assertFalse(weatherDataList.isEmpty());
    }
}