package com.exception;

public class DuplicateWeatherDataException extends Exception {

    public DuplicateWeatherDataException(String message) {
        super(message);
    }
}

