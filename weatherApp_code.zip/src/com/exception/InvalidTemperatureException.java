package com.exception;

public class InvalidTemperatureException extends Exception{
	
	public InvalidTemperatureException(String message) {
        super(message);
	}

}
