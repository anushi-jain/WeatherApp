package com.exception;

public class WeatherDataNotFoundException extends Exception {

    public WeatherDataNotFoundException(String message) {
        super(message);
    }
}
