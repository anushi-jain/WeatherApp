package com.mainClient;

import com.dao.OtherFunc;
import com.dao.WeatherDAO;
import com.model.WeatherData;
import com.exception.DuplicateWeatherDataException;
import com.exception.InvalidTemperatureException;
import com.exception.WeatherDataNotFoundException;

import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

public class WeatherAppMenu {

    private static final WeatherDAO weatherDAO = new WeatherDAO();
    private static final OtherFunc of = new OtherFunc();

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        while (true) {
            displayMenu();
            int choice = getUserChoice(scanner);

            switch (choice) {
                case 1:
                    insertWeatherData(scanner);
                    break;
                case 2:
                    deleteWeatherData(scanner);
                    break;
                case 3:
                    showAllWeatherData();
                    break;
                    
                case 4:
                	updateWeatherData();
                	break;
                	
                case 5:
                	findStateWithMaxTempInMay();
                	break;
                	
                case 6:
                	getAverageTempByState(scanner);
                	break;
                	
                case 7:
                    System.out.println("Exiting the Weather App. Goodbye!");
                    System.exit(0);
                    break;
                default:
                    System.out.println("Invalid choice. Please choose a valid option.");
            }
        }
    }

    private static void displayMenu() {
        System.out.println("===== Weather App Menu =====");
        System.out.println("1. Insert Weather Data");
        System.out.println("2. Delete Weather Data");
        System.out.println("3. Show All Weather Data");
        System.out.println("4. Updating humidity for the month of july");
        System.out.println("5. Find City with Max Temp in May");
        System.out.println("6. Get Average Temp by State");
        System.out.println("7. Exit");
        System.out.print("Enter your choice: ");
    }

    private static int getUserChoice(Scanner scanner) {
        int choice = 0;
        boolean isValidInput = false;

        while (!isValidInput) {
            try {
                choice = scanner.nextInt();
                isValidInput = true;
            } catch (InputMismatchException e) {
                System.out.println("Invalid input. Please enter a number.");
                scanner.nextLine(); // Clear the buffer
            }
        }

        return choice;
    }

    private static void insertWeatherData(Scanner scanner) {
        System.out.println("===== Insert Weather Data =====");
        // Collect user input for weather data
        // (You can modify this part based on your WeatherData class attributes)
        
        System.out.print("Enter index: ");
        int no =  scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter Region ID: ");
        int regionId =  scanner.nextInt();
        scanner.nextLine();

        System.out.print("Enter City: ");
        String city = scanner.nextLine();

        System.out.print("Enter State: ");
        String state = scanner.nextLine();
        
        System.out.print("Enter date(dd-mm-yyyy): ");
        String date = scanner.nextLine();
        
        System.out.print("Enter temp: ");
        int temperature=  scanner.nextInt();
        scanner.nextLine();
        
        System.out.print("Enter humidity: ");
        String humidity = scanner.nextLine();

        // Similar input for other attributes...

        // Create a WeatherData object with user input
        WeatherData weatherData = new WeatherData();
        weatherData.setNo(no);
        weatherData.setRegionId(regionId);
        weatherData.setCity(city);
        weatherData.setState(state);
        weatherData.setDate(date);
        weatherData.setTemperature(temperature);
        weatherData.setHumidity(humidity);

        // Call the insert method in WeatherDAO
        
        try {
            weatherDAO.insertWeatherData(weatherData);
            System.out.println("Weather data inserted successfully.");
        }catch (DuplicateWeatherDataException e) {
            System.out.println("Error: " + e.getMessage());
        } catch (InvalidTemperatureException e) {
            System.out.println("Error: " + e.getMessage());
        }

  }

    private static void deleteWeatherData(Scanner scanner) {
        System.out.println("===== Delete Weather Data =====");
        System.out.print("Enter the record number to be delete: ");
        int index = scanner.nextInt();
        scanner.nextLine();

        // Call the delete method in WeatherDAO
        try {
            weatherDAO.deleteWeatherData(index);
            System.out.println("Weather Data with ID " + index + " deleted successfully.");
        } catch (WeatherDataNotFoundException e) {
            System.out.println("Error: " + e.getMessage());
        }
    }

    private static void showAllWeatherData() {
        System.out.println("===== Show All Weather Data =====");
        // Call the getAll method in WeatherDAO
        List<WeatherData> weatherDataList = weatherDAO.getAllWeatherData();

        // Display the retrieved weather data
        for (WeatherData weatherData : weatherDataList) {
            System.out.println(weatherData);
        }
    }
    
    //update method
    private static void updateWeatherData() {
    	 System.out.println("===== Update Weather Data =====");

       	 // Call the update method in WeatherDAO
    	 weatherDAO.updateWeatherData();
    }
    
    //max temp in may
    private static void findStateWithMaxTempInMay() {
        String stateWithMaxTempInMay = of.findStateWithMaxTempInMay();
        if (stateWithMaxTempInMay != null) {
            System.out.println("State with max temp in May: " + stateWithMaxTempInMay);
        } else {
            System.out.println("Error finding state with max temp in May.");
        }
    }
    
    //Avg temp of states through out the year
    private static void getAverageTempByState(Scanner scanner) {
    	
    	scanner.nextLine();
    	
        System.out.print("Enter the state for which you want to get the average temp: ");
        String state = scanner.nextLine();

        double averageTemp = of.getAverageTempByState(state);
        if (averageTemp != 0.0) {
            System.out.println("Average temp for " + state + ": " + averageTemp);
        } else {
            System.out.println("Error getting average temp for " + state + ".");
        }
    }

}
